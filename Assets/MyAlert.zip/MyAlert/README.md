## Persyaratan

Library ini menggunakan **Font Awesome** untuk menampilkan ikon pada alert.  
Pastikan kamu sudah menambahkan Font Awesome di dalam `<head>` HTML.

```html
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

```
---

## Import Library

Tambahkan file CSS dan JavaScript menggunakan jsDelivr CDN.

### CSS
```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/hanzcode1/MyAlert@main/style.css">

```
---

### JavaScript
```html
<script src="https://cdn.jsdelivr.net/gh/hanzcode1/MyAlert@main/script.js"></script>

```
---

## Cara Penggunaan

```javascript
// Alert Sukses
MyAlert.success('Berhasil!', 'Data berhasil disimpan');

```
```javascript
// Alert Error
MyAlert.error('Gagal!', 'Terjadi kesalahan sistem');
```
```javascript
// Alert Info
MyAlert.info('Informasi', 'Ini adalah pemberitahuan');
```
```javascript
// Alert Warning
MyAlert.warning('Perhatian!', 'Harap periksa kembali');
```
```javascript
// Prompt dengan Callback
MyAlert.prompt('Masukkan nama Anda', function(value) {
    if (value) {
        console.log('Nama:', value);
    }
});

```
---

### Custom Alert dengan Opsi Lengkap

```javascript
MyAlert.show({
    type: 'success',
    title: 'Pembelian Berhasil!',
    message: 'Terima kasih telah berbelanja',
    confirmText: 'Lihat Pesanan',
    cancelText: 'Tutup',
    showCancel: true,
    closeOnOverlay: true,
    autoClose: 5000, // Auto close dalam 5 detik
    onConfirm: function() {
        console.log('Konfirmasi diklik');
    },
    onCancel: function() {
        console.log('Batal diklik');
    }
});

```
---

## Referensi API

| Method | Parameter | Deskripsi |
|------|----------|----------|
| `MyAlert.success(title, message, callback)` | `title`, `message`, `callback` (opsional) | Menampilkan alert sukses dengan ikon centang hijau |
| `MyAlert.error(title, message, callback)` | `title`, `message`, `callback` (opsional) | Menampilkan alert error dengan ikon silang merah dan efek shake |
| `MyAlert.info(title, message, callback)` | `title`, `message`, `callback` (opsional) | Menampilkan alert informasi dengan ikon info berwarna biru |
| `MyAlert.warning(title, message, callback)` | `title`, `message`, `callback` (opsional) | Menampilkan alert peringatan dengan ikon warning kuning |
| `MyAlert.prompt(title, callback, placeholder)` | `title`, `callback`, `placeholder` (opsional) | Menampilkan alert dengan input field dan mengembalikan nilai input melalui callback |
| `MyAlert.show(options)` | `object options` | Menampilkan alert dengan konfigurasi lengkap dan fleksibel |
| `MyAlert.close()` | - | Menutup alert yang sedang aktif secara programatis |

## Opsi Konfigurasi

| Opsi | Tipe | Default | Deskripsi |
|-----|------|---------|-----------|
| `type` | string | `'info'` | Tipe alert: `success`, `error`, `info`, `warning`, `prompt` |
| `title` | string | `''` | Judul alert |
| `message` | string | `''` | Pesan atau deskripsi alert |
| `confirmText` | string | `'OK'` | Teks tombol konfirmasi |
| `cancelText` | string | `'Batal'` | Teks tombol batal |
| `showCancel` | boolean | `false` | Menampilkan tombol batal |
| `showClose` | boolean | `true` | Menampilkan tombol X untuk menutup |
| `closeOnOverlay` | boolean | `true` | Menutup alert saat overlay diklik |
| `autoClose` | number \| false | `false` | Auto close dalam milidetik (`false` = nonaktif) |
| `placeholder` | string | `''` | Placeholder untuk input (tipe `prompt`) |
| `inputType` | string | `'text'` | Tipe input HTML (`text`, `email`, `password`, dll) |
| `onConfirm` | function | `null` | Callback saat tombol konfirmasi diklik |
| `onCancel` | function | `null` | Callback saat tombol batal diklik |
| `onClose` | function | `null` | Callback saat alert ditutup (dengan cara apa pun) |
